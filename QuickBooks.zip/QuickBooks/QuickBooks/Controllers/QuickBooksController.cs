﻿using Intuit.Ipp.OAuth2PlatformClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace QuickBooks.Controllers
{
    [RoutePrefix("api/QB")]
    public class QuickBooksController : ApiController
    {
        #region Properties

        public static string clientid = ConfigurationManager.AppSettings["clientid"];
        public static string clientsecret = ConfigurationManager.AppSettings["clientsecret"];
        public static string redirectUrl = ConfigurationManager.AppSettings["redirectUrl"];
        public static string environment = ConfigurationManager.AppSettings["appEnvironment"];
        public static string realmId = ConfigurationManager.AppSettings["realmId"];
        public static string qboUrl = ConfigurationManager.AppSettings["qboUrl"];

        public static OAuth2Client auth2Client = new OAuth2Client(clientid, clientsecret, redirectUrl, environment);
        #endregion       

        #region Get Items
        /// <summary>
        /// Get any details of records from quickbooks using selecting query. For example, Select * from Customer/ Select * from Invoice...etc
        /// </summary>
        /// <param name="Query">Look like SQL query. For example, Select * from Customer/ Select * from Invoice...etc</param>
        /// <returns>Returns set number of selecting rows</returns>
        [HttpGet]
        [AllowAnonymous]
        [Route("GetItems")]
        public async Task<HttpResponseMessage> GetItems(string Query = "")
        {
            try
            {
                if (string.IsNullOrEmpty(Query))
                {
                    return Request.CreateResponse(HttpStatusCode.NotImplemented);
                }

                string accessToken = await GetAccessToken();

                string uri = string.Format("{0}{1}/query?query={2}", qboUrl, realmId, Query);

                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("ContentType", "application/json;charset=UTF-8");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                var result = await client.GetAsync(uri);

                var responseContent = await result.Content.ReadAsStringAsync();

                return result;

            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.NotImplemented, ex.Message);
            }
        }
        #endregion

        #region Customer
        /// <summary>
        /// Add or Update customers
        /// </summary>
        /// <param name="customer">
        /// JSON input example 
        /// {
        ///  "FullyQualifiedName": "OptisolMML", 
        ///  "PrimaryEmailAddr": {
        ///    "Address": "optisol@yopamail.com"
        ///  }, 
        ///  "DisplayName": "OptisolMML", 
        ///  "Suffix": "Jr", 
        ///  "Title": "Mr", 
        ///  "MiddleName": "B", 
        ///  "Notes": "Here are other details.", 
        ///  "FamilyName": "King", 
        ///  "PrimaryPhone": {
        ///    "FreeFormNumber": "(111) 111-1111"
        ///  }, 
        ///  "CompanyName": "MML", 
        ///  "BillAddr": {
        ///    "CountrySubDivisionCode": "CA", 
        ///    "City": "Mountain View", 
        ///    "PostalCode": "94042", 
        ///    "Line1": "123 Main Street", 
        ///    "Country": "USA"
        ///  }, 
        ///  "GivenName": "James"
        ///}
        /// </param>
        /// <returns>returns customer json</returns>

        [HttpPost]
        [AllowAnonymous]
        [Route("Customer")]

        public async Task<HttpResponseMessage> Customer(object customer)
        {
            try
            {
                if (customer == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotImplemented);
                }

                string customerJson = JsonConvert.SerializeObject(customer, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore
                });

                string accessToken = await GetAccessToken();

                //add qbobase url and query
                string uri = string.Format("{0}{1}/{2}", qboUrl, realmId, "customer");

                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("ContentType", "application/json;charset=UTF-8");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                var result = await client.PostAsync(uri, new StringContent(customerJson, System.Text.Encoding.UTF8, "application/json"));

                var responseContent = await result.Content.ReadAsStringAsync();

                return result;
            }

            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.NotImplemented, ex.Message);
            }
        }
        #endregion

        #region Invoice
        /// <summary>
        /// Add or Update Invoice
        /// </summary>
        /// <param name="invoiceId">JSON input. For example
        /// {
        //  "Line": [
        //    {
        //      "DetailType": "SalesItemLineDetail",
        //      "Amount": 100.0,
        //      "SalesItemLineDetail": {
        //        "ItemRef": {
        //          "name": "Services",
        //          "value": "1"
        //        }
        //}
        //    }
        //  ], 
        //"BillEmail" : {
        //  	 "Address" : "mml@yopmail.com"
        //  },
        //  "CustomerRef": {
        //    "value": "8"
        //  }
        //}</param>
        /// <returns>returns Invoice json</returns>
        [HttpPost]
        [AllowAnonymous]
        [Route("Invoice")]
        public async Task<HttpResponseMessage> Invoice(object invoice)
        {
            try
            {
                if (invoice == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotImplemented);
                }

                string invoiceJson = JsonConvert.SerializeObject(invoice, new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore
                });

                string accessToken = await GetAccessToken();

                //add qbobase url and query
                string uri = string.Format("{0}{1}/{2}", qboUrl, realmId, "invoice");

                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("ContentType", "application/json");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer" + accessToken);
                var result = await client.PostAsync(uri, new StringContent(invoiceJson, System.Text.Encoding.UTF8, "application/json"));

                var responseContent = await result.Content.ReadAsStringAsync();

                return result;
            }

            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.NotImplemented, ex.Message);
            }
        }
        #endregion
        #region Send Invioce 
       /// <summary>
       /// Send invoice to customer
       /// </summary>
       /// <param name="invoiceId">ID of the invoice.</param>
       /// <returns>returns invoice JSON</returns>
        [HttpPost]
        [AllowAnonymous]
        [Route("SendInvoice")]
        public async Task<HttpResponseMessage> SendInvoice(string invoiceId)
        {
            try
            {
                if (string.IsNullOrEmpty(invoiceId))
                {
                    return Request.CreateResponse(HttpStatusCode.NotImplemented);
                }

                string accessToken = await GetAccessToken();

                //add qbobase url and query
                string uri = string.Format("{0}{1}/{2}/{3}/send", qboUrl, realmId, "invoice", invoiceId);

                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("ContentType", "application/json");
                client.DefaultRequestHeaders.Add("Authorization", "Bearer" + accessToken);
                var result = await client.PostAsync(uri, null);

                var responseContent = await result.Content.ReadAsStringAsync();

                return result;
            }

            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.NotImplemented, ex.Message);
            }
        }
        #endregion

        #region Helper Methods
        public async Task<string> GetAccessToken()
        {
            try
            {
                ExeConfigurationFileMap configMap = new ExeConfigurationFileMap();

                configMap.ExeConfigFilename = AppDomain.CurrentDomain.BaseDirectory + @"QBConfig\QBConfig.config";

                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);

                string refreshToken = config.AppSettings.Settings["refreshToken"].Value;

                TokenResponse tokenResp = await auth2Client.RefreshTokenAsync(refreshToken);

                if ((!string.IsNullOrEmpty(refreshToken)) && (refreshToken != tokenResp.RefreshToken))
                {
                    config.AppSettings.Settings["refreshToken"].Value = tokenResp.RefreshToken;
                    config.Save();
                }

                return tokenResp.AccessToken;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion
    }
}
